/*{
	el: '#app',
	template: <input v-model='test'></input>,
	data: {
		test: 1
	}
}*/

var compile = function(template) {
    var wrapper = document.createElement('div')
    wrapper.innerHTML = template
    var el = wrapper.childNodes[0]
    var model = el.getAttribute('v-model')
    return {
        el,
        model
    }
}

var observe = function(data, key) {
    var watchers = []
    Object.defineProperty(data, key, {
        set(val) {
            var oldVal = data[key]
            watchers.map(cb => {
                cb(oldVal, val)
            })
        }
    })
    return watchers
}
var Observal = function( data ) {
	var observers = {}
    for (let key in data) {
        observers[key] = observe(data, key)
    }
    return observers
}
var myVue = function(options) {
	const _vm = this
	this.data = options.data
	var compiledElement = compile(options.template)
	compiledElement.el.addEventListener('input', function(e){
		_vm.data[compiledElement.model] = e.target.value
	})
	var ob = Observal( options.data )
	ob[compiledElement.model].push(function(oldVal, val){
		compiledElement.el.value = val
	})
	var el = document.querySelector(options.el)
	el.appendChild( compiledElement.el )
}

new myVue({
	el: '#app',
	template: '<input v-model="test"></input>',
	data: {
		test: 1
	}
})